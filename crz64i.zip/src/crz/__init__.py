"""
CRZ64I main package.
"""
__version__ = "0.1.0"

from .config import load_config
