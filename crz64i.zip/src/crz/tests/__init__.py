"""
CRZ64I tests package.
"""
