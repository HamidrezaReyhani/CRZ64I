"""
CRZ64I CLI package.
"""
