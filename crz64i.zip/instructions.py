# instructions.py
# CRZ64I Instruction Set Definition

INSTRUCTIONS = {
    # Control Flow (8)
    'NOP': {'opcode': 0x00, 'format': 'N', 'operands': 0, 'latency': 1, 'energy': 0.1},
    'BR': {'opcode': 0x01, 'format': 'B', 'operands': 1, 'latency': 1, 'energy': 0.2},
    'BR_IF': {'opcode': 0x02, 'format': 'B', 'operands': 4, 'latency': 1, 'energy': 0.3},
    'CALL': {'opcode': 0x03, 'format': 'B', 'operands': 1, 'latency': 2, 'energy': 0.5},
    'RET': {'opcode': 0x04, 'format': 'N', 'operands': 0, 'latency': 2, 'energy': 0.5},
    'YIELD': {'opcode': 0x05, 'format': 'N', 'operands': 0, 'latency': 3, 'energy': 0.8},
    'TRAP': {'opcode': 0x06, 'format': 'I', 'operands': 1, 'latency': 5, 'energy': 1.0},
    'HALT': {'opcode': 0x07, 'format': 'N', 'operands': 0, 'latency': 1, 'energy': 0.1},

    # Integer and Bitwise (10)
    'ADD': {'opcode': 0x08, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.5},
    'SUB': {'opcode': 0x09, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.5},
    'MUL': {'opcode': 0x0A, 'format': 'R', 'operands': 3, 'latency': 2, 'energy': 1.0},
    'DIV': {'opcode': 0x0B, 'format': 'R', 'operands': 3, 'latency': 10, 'energy': 5.0},
    'AND': {'opcode': 0x0C, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.3},
    'OR': {'opcode': 0x0D, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.3},
    'XOR': {'opcode': 0x0E, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.3},
    'SHL': {'opcode': 0x0F, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.4},
    'SHR': {'opcode': 0x10, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.4},
    'POPCNT': {'opcode': 0x11, 'format': 'R', 'operands': 2, 'latency': 2, 'energy': 0.8},

    # Memory and I/O (8)
    'LOAD': {'opcode': 0x12, 'format': 'I', 'operands': 2, 'latency': 2, 'energy': 1.0},
    'STORE': {'opcode': 0x13, 'format': 'I', 'operands': 2, 'latency': 2, 'energy': 1.0},
    'LOADF': {'opcode': 0x14, 'format': 'I', 'operands': 2, 'latency': 2, 'energy': 1.0},
    'STOREF': {'opcode': 0x15, 'format': 'I', 'operands': 2, 'latency': 2, 'energy': 1.0},
    'ATOMIC_INC': {'opcode': 0x16, 'format': 'I', 'operands': 1, 'latency': 3, 'energy': 1.5},
    'DMA_START': {'opcode': 0x17, 'format': 'I', 'operands': 3, 'latency': 1, 'energy': 0.5},
    'CACHE_LOCK': {'opcode': 0x18, 'format': 'I', 'operands': 2, 'latency': 1, 'energy': 0.3},
    'PREFETCH': {'opcode': 0x19, 'format': 'I', 'operands': 1, 'latency': 1, 'energy': 0.2},

    # Vector/SIMD (10)
    'VLOAD': {'opcode': 0x1A, 'format': 'V', 'operands': 2, 'latency': 3, 'energy': 1.5},
    'VSTORE': {'opcode': 0x1B, 'format': 'V', 'operands': 2, 'latency': 3, 'energy': 1.5},
    'VADD': {'opcode': 0x1C, 'format': 'V', 'operands': 3, 'latency': 2, 'energy': 1.0},
    'VSUB': {'opcode': 0x1D, 'format': 'V', 'operands': 3, 'latency': 2, 'energy': 1.0},
    'VMUL': {'opcode': 0x1E, 'format': 'V', 'operands': 3, 'latency': 3, 'energy': 2.0},
    'VDOT32': {'opcode': 0x1F, 'format': 'V', 'operands': 3, 'latency': 4, 'energy': 2.0},
    'VSHL': {'opcode': 0x20, 'format': 'V', 'operands': 2, 'latency': 2, 'energy': 0.8},
    'VSHR': {'opcode': 0x21, 'format': 'V', 'operands': 2, 'latency': 2, 'energy': 0.8},
    'VFMA': {'opcode': 0x22, 'format': 'V', 'operands': 4, 'latency': 4, 'energy': 2.5},
    'VREDUCE_SUM': {'opcode': 0x23, 'format': 'V', 'operands': 2, 'latency': 5, 'energy': 3.0},

    # Floating-Point (4)
    'FADD': {'opcode': 0x24, 'format': 'R', 'operands': 3, 'latency': 2, 'energy': 1.0},
    'FSUB': {'opcode': 0x25, 'format': 'R', 'operands': 3, 'latency': 2, 'energy': 1.0},
    'FMUL': {'opcode': 0x26, 'format': 'R', 'operands': 3, 'latency': 3, 'energy': 1.5},
    'FMA': {'opcode': 0x27, 'format': 'R', 'operands': 4, 'latency': 4, 'energy': 2.0},

    # Atomic and Synchronization (4)
    'LOCK': {'opcode': 0x28, 'format': 'I', 'operands': 1, 'latency': 5, 'energy': 2.0},
    'UNLOCK': {'opcode': 0x29, 'format': 'I', 'operands': 1, 'latency': 3, 'energy': 1.0},
    'CMPXCHG': {'opcode': 0x2A, 'format': 'I', 'operands': 3, 'latency': 4, 'energy': 1.8},
    'FENCE': {'opcode': 0x2B, 'format': 'N', 'operands': 0, 'latency': 2, 'energy': 0.5},

    # System and Power Management (6)
    'SET_PWR_MODE': {'opcode': 0x2C, 'format': 'I', 'operands': 1, 'latency': 10, 'energy': 0.1},
    'GET_PWR_STATE': {'opcode': 0x2D, 'format': 'R', 'operands': 1, 'latency': 2, 'energy': 0.3},
    'THERM_READ': {'opcode': 0x2E, 'format': 'R', 'operands': 1, 'latency': 5, 'energy': 0.5},
    'SET_THERM_POLICY': {'opcode': 0x2F, 'format': 'I', 'operands': 1, 'latency': 10, 'energy': 0.1},
    'SLEEP': {'opcode': 0x30, 'format': 'I', 'operands': 1, 'latency': 1, 'energy': 0.01},
    'FAST_PATH_ENTER': {'opcode': 0x31, 'format': 'N', 'operands': 0, 'latency': 5, 'energy': 1.0},

    # Reversible Operations (6)
    'SAVE_DELTA': {'opcode': 0x32, 'format': 'R', 'operands': 2, 'latency': 1, 'energy': 0.5},
    'RESTORE_DELTA': {'opcode': 0x33, 'format': 'R', 'operands': 2, 'latency': 1, 'energy': 0.5},
    'REV_ADD': {'opcode': 0x34, 'format': 'R', 'operands': 3, 'latency': 1, 'energy': 0.4},
    'REV_SWAP': {'opcode': 0x35, 'format': 'R', 'operands': 2, 'latency': 1, 'energy': 0.3},
    'ADIABATIC_START': {'opcode': 0x36, 'format': 'N', 'operands': 0, 'latency': 5, 'energy': 0.1},
    'ADIABATIC_STOP': {'opcode': 0x37, 'format': 'N', 'operands': 0, 'latency': 5, 'energy': 0.1},

    # Cryptographic and Hash (4)
    'CRC32': {'opcode': 0x38, 'format': 'R', 'operands': 3, 'latency': 10, 'energy': 5.0},
    'HASH_INIT': {'opcode': 0x39, 'format': 'R', 'operands': 1, 'latency': 5, 'energy': 2.0},
    'HASH_UPDATE': {'opcode': 0x3A, 'format': 'I', 'operands': 3, 'latency': 8, 'energy': 4.0},
    'HASH_FINAL': {'opcode': 0x3B, 'format': 'R', 'operands': 2, 'latency': 5, 'energy': 2.0},

    # Miscellaneous (4)
    'PROFILE_START': {'opcode': 0x3C, 'format': 'I', 'operands': 1, 'latency': 1, 'energy': 0.1},
    'PROFILE_STOP': {'opcode': 0x3D, 'format': 'I', 'operands': 1, 'latency': 1, 'energy': 0.1},
    'TRACE': {'opcode': 0x3E, 'format': 'I', 'operands': 1, 'latency': 1, 'energy': 0.2},
    'EXTENSION': {'opcode': 0x3F, 'format': 'I', 'operands': 2, 'latency': 1, 'energy': 0.5},
}

# Registers: R0-R63, V0-V7
NUM_REGS = 64
NUM_VREGS = 8
